<TABLE WIDTH=100% BORDER=0 CELLPADDING=4 CELLSPACING=4 STYLE="page-break-before: always">
<COL WIDTH=64*>
<COL WIDTH=64*>
<COL WIDTH=64*>
<COL WIDTH=64*>
<TR VALIGN=TOP>
<TD WIDTH=25%>
<P ALIGN=CENTER><A HREF="./add-url.php"><FONT COLOR="#579d1c"><B>Add
URLs</B></FONT></A></P>
</TD>
<TD WIDTH=25%>
<P ALIGN=CENTER><FONT COLOR="#579d1c"><A HREF="./delete-url.php"><FONT COLOR="#008000"><B>Delete
URLs</B></FONT></A></FONT></P>
</TD>
<TD WIDTH=25%>
<P ALIGN=CENTER><FONT COLOR="#579d1c"><A HREF="./search-url.php"><FONT COLOR="#008000"><B>Search
URLs</B></FONT></A></FONT></P>
</TD>
<TD WIDTH=25%>
<P ALIGN=CENTER><FONT COLOR="#579d1c"><A HREF="./display-url-list.php"><FONT COLOR="#008000"><B>Display
URL list</B></FONT></A></FONT></P>
</TD>
</TR>
<TR VALIGN=TOP>
<TD WIDTH=25%>
<P ALIGN=CENTER><A HREF="./block-url-net-access.php"><FONT COLOR="#00cccc"><B>Block
Network URL List Access</B></FONT></A></P>
</TD>
<TD WIDTH=25%>
<P ALIGN=CENTER><A HREF="./unblock-url-net-access.php"><FONT COLOR="#00cccc"><B>Unblock
Network URL List Access</B></FONT></A></P>
</TD>
<TD WIDTH=25%>
<P ALIGN=CENTER><A HREF="./lookup-net-ip.php"><FONT COLOR="#00cccc"><B>Lookup
Network List IP range</B></FONT></A></P>
</TD>
<TD WIDTH=25%>
<P ALIGN=CENTER><A HREF="./display-rules.php"><FONT COLOR="#00cccc"><B>Display Rules</B></FONT></A></P>
</TD>
</TR>
</TABLE>
<P><BR>

<table style="text-align: left; width: 100%;" border="0" cellpadding="0"
cellspacing="0">
<tbody>
<tr>
<td style="vertical-align: top; background-color: rgb(0, 153, 0);"><br>
</td>
<td style="vertical-align: top;"><br>
</td>
</tr>
<tr>
<td style="vertical-align: top;"><br clear="all">
</td>
<td
style="vertical-align: top; background-color: rgb(255, 204, 0);"><br
clear="all">
</td>
</tr>
</tbody>
</table>
<br>
